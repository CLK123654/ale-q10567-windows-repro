{{- define "billing-service.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{- define "billing-service.fullname" -}}
{{- printf "%s-%s" .Release.Name (include "billing-service.name" .) | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{- define "billing-service.labels" -}}
billing.example.com/name: {{ include "billing-service.name" . }}
billing.example.com/instance: {{ .Release.Name }}
billing.example.com/managed-by: {{ .Release.Service }}
helm.sh/chart: {{ .Chart.Name }}-{{ .Chart.Version | replace "+" "_" }}
billing.example.com/part-of: internet-billing
billing.example.com/environment: {{ .Values.environment | quote }}
{{- end -}}
