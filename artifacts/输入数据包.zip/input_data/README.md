# 计费服务多环境发布材料

`starter/chart/billing-service`是待完善的起始Chart，已经包含公共配置、开发环境覆盖、生产环境覆盖以及Deployment和Service骨架。`rules/billing_render_contract.yaml`记录Chart身份、必需模板、Secret字段、配额字段和环境差异关系。

把完成的Chart放在输入目录同级的`output/chart/billing-service`。随后在`input_data`目录运行`npm run process`，入口会调用Helm生成两个环境的渲染清单和差异报告。

本次材料来自计费服务发布工单。环境名称、镜像地址和Secret名称已经脱敏，包内不含凭据值。
