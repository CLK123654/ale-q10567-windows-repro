import fs from 'node:fs/promises';
import path from 'node:path';
import { spawnSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';

const inputRoot = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const taskRoot = path.resolve(inputRoot, '..');
const chartRoot = path.join(taskRoot, 'output', 'chart', 'billing-service');
const renderedRoot = path.join(taskRoot, 'output', 'rendered');
const reportsRoot = path.join(taskRoot, 'output', 'reports');
const contractPath = path.join(inputRoot, 'rules', 'billing_render_contract.yaml');

function scalar(value) {
  const trimmed = value.trim();
  if ((trimmed.startsWith('"') && trimmed.endsWith('"')) || (trimmed.startsWith("'") && trimmed.endsWith("'"))) return trimmed.slice(1, -1);
  return trimmed;
}

function flatYaml(text) {
  const result = {};
  const stack = [];
  for (const raw of text.split(/\r?\n/u)) {
    if (!raw.trim() || raw.trimStart().startsWith('#') || raw.trimStart().startsWith('- ')) continue;
    const match = raw.match(/^(\s*)([^:#][^:]*):(?:\s*(.*))?$/u);
    if (!match) continue;
    const level = Math.floor(match[1].length / 2);
    stack.length = level;
    stack[level] = match[2].trim();
    if ((match[3] ?? '').trim()) result[stack.join('.')] = scalar(match[3]);
  }
  return result;
}

function listAt(text, key) {
  const lines = text.split(/\r?\n/u);
  const start = lines.findIndex((line) => new RegExp(`^(\\s*)${key}:\\s*$`, 'u').test(line));
  if (start < 0) throw new Error(`发布合同缺少${key}`);
  const indent = lines[start].match(/^\s*/u)[0].length;
  const values = [];
  for (let index = start + 1; index < lines.length; index += 1) {
    const line = lines[index];
    if (!line.trim()) continue;
    const current = line.match(/^\s*/u)[0].length;
    if (current <= indent) break;
    if (current === indent + 2 && line.trimStart().startsWith('- ')) values.push(scalar(line.trimStart().slice(2)));
  }
  return values;
}

function helm(binary, args) {
  const result = spawnSync(binary, args, { encoding: 'utf8', timeout: 30000, windowsHide: true });
  if (result.status !== 0) throw new Error(result.stderr || result.stdout || `Helm命令失败：${args[0]}`);
  return result.stdout;
}

function normalizeRender(value) {
  const lines = value.replaceAll('\r\n', '\n').split('\n').filter((line) => !line.startsWith('# Source:') && line.trim() !== '');
  return `${lines.join('\n').trim()}\n`;
}

function csvCell(value) {
  const text = String(value);
  return /[",\n\r]/u.test(text) ? `"${text.replaceAll('"', '""')}"` : text;
}

function csvString(columns, rows) {
  return `${[columns.join(','), ...rows.map((row) => columns.map((column) => csvCell(row[column])).join(','))].join('\n')}\n`;
}

function cpuMillicores(value) {
  if (!/^\d+m$/u.test(value)) throw new Error(`无法换算CPU请求值${value}`);
  return Number(value.slice(0, -1));
}

function memoryMi(value) {
  const match = value.match(/^(\d+)(Mi|Gi)$/u);
  if (!match) throw new Error(`无法换算内存上限值${value}`);
  return Number(match[1]) * (match[2] === 'Gi' ? 1024 : 1);
}

function model(name, contract, common, env) {
  return {
    release: contract[`chart.releaseNames.${name}`],
    namespace: env.namespace,
    replicaCount: Number(env.replicaCount),
    secretName: env.secretName,
    cpuRequest: cpuMillicores(env['resources.requests.cpu']),
    memoryLimit: memoryMi(env['resources.limits.memory']),
    dailyInvoiceLimit: Number(env['quota.dailyInvoiceLimit']),
    workerConcurrency: Number(env['quota.workerConcurrency']),
    refundBatchSize: Number(env['quota.refundBatchSize']),
    fraudHoldPct: env['quota.fraudHoldPct'],
    auditExporterEnabled: env['audit.exporterEnabled'],
    image: `${common['image.repository']}:${common['image.tag']}`,
  };
}

async function main() {
  const contractText = await fs.readFile(contractPath, 'utf8');
  const contract = flatYaml(contractText);
  const requiredTemplates = listAt(contractText, 'requiredTemplates').toSorted();
  const actualTemplates = (await fs.readdir(path.join(chartRoot, 'templates'))).filter((name) => !name.startsWith('.')).toSorted();
  if (JSON.stringify(actualTemplates) !== JSON.stringify(requiredTemplates)) throw new Error('Chart模板与发布合同不一致');
  const common = flatYaml(await fs.readFile(path.join(chartRoot, 'values.yaml'), 'utf8'));
  const environments = {};
  for (const name of ['dev', 'prod']) {
    const valuesPath = path.join(chartRoot, 'values', 'env', `${name}.yaml`);
    environments[name] = model(name, contract, common, flatYaml(await fs.readFile(valuesPath, 'utf8')));
  }

  const helmBinary = process.env.ALE_HELM_BIN || (process.platform === 'win32' ? 'helm.exe' : 'helm');
  await fs.rm(renderedRoot, { recursive: true, force: true });
  await fs.rm(reportsRoot, { recursive: true, force: true });
  await fs.mkdir(renderedRoot, { recursive: true });
  await fs.mkdir(reportsRoot, { recursive: true });

  for (const name of ['dev', 'prod']) {
    const valuesPath = path.join(chartRoot, 'values', 'env', `${name}.yaml`);
    helm(helmBinary, ['lint', chartRoot, '--values', valuesPath]);
    const rendered = helm(helmBinary, ['template', environments[name].release, chartRoot, '--namespace', environments[name].namespace, '--values', valuesPath]);
    await fs.writeFile(path.join(renderedRoot, `${name}.yaml`), normalizeRender(rendered));
  }

  const metricValues = {
    replica_count: [environments.dev.replicaCount, environments.prod.replicaCount, 'values/env.replicaCount'],
    cpu_request_millicores: [environments.dev.cpuRequest, environments.prod.cpuRequest, 'values/env.resources.requests.cpu'],
    memory_limit_mi: [environments.dev.memoryLimit, environments.prod.memoryLimit, 'values/env.resources.limits.memory'],
    daily_invoice_limit: [environments.dev.dailyInvoiceLimit, environments.prod.dailyInvoiceLimit, 'values/env.quota.dailyInvoiceLimit'],
    worker_concurrency: [environments.dev.workerConcurrency, environments.prod.workerConcurrency, 'values/env.quota.workerConcurrency'],
    refund_batch_size: [environments.dev.refundBatchSize, environments.prod.refundBatchSize, 'values/env.quota.refundBatchSize'],
    fraud_hold_pct: [environments.dev.fraudHoldPct, environments.prod.fraudHoldPct, 'values/env.quota.fraudHoldPct'],
    audit_exporter_enabled: [environments.dev.auditExporterEnabled, environments.prod.auditExporterEnabled, 'values/env.audit.exporterEnabled'],
    secret_name: [environments.dev.secretName, environments.prod.secretName, 'values/env.secretName'],
  };
  const rows = listAt(contractText, 'diffKeys').map((key) => {
    const values = metricValues[key];
    const relation = contract[`diffRelations.${key}`];
    if (!values || !relation) throw new Error(`差异规则无法解析${key}`);
    return { check_key: key, dev_value: values[0], prod_value: values[1], expected_relation: relation, source: values[2] };
  });
  await fs.writeFile(path.join(reportsRoot, 'render_diff.csv'), csvString(['check_key', 'dev_value', 'prod_value', 'expected_relation', 'source'], rows));
  console.log(`已生成${rows.length}项多环境发布差异`);
}

main().catch((error) => {
  console.error(error.message);
  process.exitCode = 1;
});
